//
//  ViewController.swift
//  Ex01-Tab-Seasons
//
//  Created by Hussein Alsowadi on 4/21/22.
//  xcode version 10.1
//Everything works great 
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

