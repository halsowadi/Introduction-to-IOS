//
//  ViewController.swift
//  Ex02-Page-Seasons
//
//  Created by Hussein Alsowadi on 4/21/22.
//  Xcode version 10.1
//Everything works fine with this app
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

